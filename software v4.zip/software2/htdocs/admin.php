<?php 
include("include/menuAdmin.php"); 

?>


<!-- MENU-->

<div class="content">
	<div class="about-section" id="about">
		<div class="container">
			<div class="row">
				
				<div class="col-md-3">
					<h3>Restaurantes </h3>
				</div>
				<div class="col-md-5"></div>
				<div class="col-md-4">
				</div>
			</div>

			<div class="main wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;"> 


				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
<!-- //MENU -->

