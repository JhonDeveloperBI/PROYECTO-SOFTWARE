<html> 
<body> 
<form method="POST" action="buscar.php"> 
<strong>Palabra clave:</strong> <input type="text" name="buscar" size="20"><br><br> 
<input type="submit" value="buscar" name="buscar"> 
</form> 
</body> 
</html>