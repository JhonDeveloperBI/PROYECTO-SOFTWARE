<?php
require_once("BaseDatos.php");
/************************
$host = "mysql15.000webhost.com";
$port = 3306;
$bd = "a4940393_biblio";
$user = "a4940393_createS";
$pw = "b123654";
************************/
define("HOST", "localhost");
define("PORT", 3306);
define("USER", "root");
define("PASSWORD", "");
define("BD", "b5_19129423_Fasty");
$db = new BaseDatos(HOST,PORT,USER,PASSWORD,BD);
//$db->ejecutarConsulta("set names'utf8'");
?>