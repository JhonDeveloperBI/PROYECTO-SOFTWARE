<?php

if(!empty($_POST)){
	if(isset($_POST["username"]) &&isset($_POST["password"])){
		if($_POST["username"]!=""&&$_POST["password"]!=""){
			include "conexion.php";
			
			$user_id=null;
			$sql1= "SELECT * FROM administrador where (username=\"$_POST[username]\" or correo=\"$_POST[username]\") and password=\"$_POST[password]\" ";
			//$sql1= "SELECT * FROM administrador where (username='marias') and password='11' ";
			
			$query = $con->query($sql1) or die (mysqli_error());
			
			
			while ($r=$query->fetch_array()) {
				$user_id=$r["id"];
				break;
			}
			if($user_id==null){
				print "<script>alert(\"Acceso invalido.\");window.location='../login.php';</script>";
			}else{
				session_start();
				$_SESSION["user_id"]=$user_id;
				print "<script>window.location='../home.php';</script>";				
			}
			
		}
	}
}



?>