<?php
$host="localhost";
$user="root";
$password="";
$db="software";
$con = new mysqli($host,$user,$password,$db);

if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


?>