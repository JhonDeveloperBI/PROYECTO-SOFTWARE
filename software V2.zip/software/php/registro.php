<?php

			include "conexion.php";
			
			$found=false;
			$sql1= "SELECT * FROM administrador where nombre=\"$_POST[username]\" or correo=\"$_POST[email]\" or username=\"$_POST[fullname]\" ";
			$query = $con->query($sql1) or die (mysqli_error()); 

if ($query->num_rows >0) {
			$found=true;
}


			if($found){
				print "<script>alert(\"Nombre de usuario o email ya estan registrados.\");window.location='../registro.php';</script>";
			}
			
			$nombre=$_POST["username"];
			$username=$_POST["fullname"];
			$telefono=$_POST["telefono"];
			$password=$_POST["password"];
			$correo=$_POST["email"];


if($found==false)
{
			$sql = 'INSERT INTO administrador(nombre,username,telefono,correo,password) VALUES("'.$nombre.'", "'.$username.'","'.$telefono.'","'.$correo.'","'.$password.'")';
			$query = $con->query($sql) or die (mysqli_error());
			if($query!=null){
				print "<script>alert(\"Registro exitoso. Proceda a logearse\");window.location='../login.php';</script>";
			}
			else
				echo "error";
}
$con->close();

?>