<?php
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
print "<script>alert(\"Acceso invalido!\");window.location='login.php';</script>";
}

?>
<html lang="en">
<?php include "php/navbar.php"; ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Administrador de Establecimientos</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                
                
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Luce <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                 <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="home.php"><i class="fa fa-fw fa-dashboard"></i> inicio</a>
                    </li>
                    <li>
                        <a href="regitrarEstablecimientos.php"><i class="fa fa-fw fa-bar-chart-o"></i> Registros Establecimientos</a>
                    </li>
                    <li>
                        <a href="informacionEstablecimiento.php"><i class="fa fa-fw fa-table"></i>Informacion Establecimientos</a>
                    </li>
                   
                                </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Informacion establecimientos
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="home.php">Inicio</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-table"></i> Informacion Establecimientos
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

               

              
                </div>
                <!-- /.row -->

                <div class="row">
                    
                   <?php  
//tomamos los datos del archivo conexion.php  
include("php/conexion.php");    
//se envia la consulta  
$result = "SELECT * FROM establecimientos"; 

//$result = $con->query($sql1) or die (mysqli_error());
$query = $con->query($result) or die (mysqli_error());
//se despliega el resultado
echo " <div class='table-responsive'>" ; 
echo "<table class='table table-hover table-striped'>";
echo "<thead>
<tr> 
<th>Nombre</th> 
<th>Direccion</th> 
<th>Telefono</th> 
<th>Descripcion</th> 
<th>Hora</th> 
<th>Ubicacion</th> 
    </tr>
</thead>"; 


echo "<tbody>";
while ($row = mysqli_fetch_array($query)){   
    echo "<tr>";  
    echo "<td>$row[nombre]></td>";  
    echo "<td>$row[direccion]</td>";  
    echo "<td>$row[telefono]</td>";
    echo "<td>$row[descripcion]</td>";
    echo "<td>$row[hora]</td>";
    echo "<td>$row[UbicacionGps]</td>";  
    echo "</tr>";  
}
echo"</tbody>";
echo "</table>";    
echo"</div>";
$con->close();
?>  
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
