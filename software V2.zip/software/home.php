<?php
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
print "<script>alert(\"Acceso invalido!\");window.location='login.php';</script>";
}

?>

<html lang="en">
<?php include "php/navbar.php"; ?>
<head>

    <style type="text/css">
    html, body { height: 100%; margin: 0; padding: 0; }
    #map { height: 100%; }
   </style>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Administrador de  establecimientos</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

<!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
   <!--
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>
   -->

<script type="text/javascript" src="jquery-1.6.1.min.js"></script>
 <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBlovBGBnGTT4rsmbx-nQfH1BtLvn97y38&callback=initMap"></script>
    <script type="text/javascript">

function initMap() {
  var map = new google.maps.Map(document.getElementById('map'), {
    center: {lat:  4.555911, lng:-75.659844},
     mapTypeControl: true,
    zoom: 20
  });


 var image =
        { 
          url: "green.png",
          // This marker is 20 pixels wide by 32 pixels high.
          size: new google.maps.Size(32,32),
          // The origin for this image is (0, 0).
          origin: new google.maps.Point(0,0),
           
          // The anchor for this image is the base of the flagpole at (0, 32).
          anchor: new google.maps.Point(0, 32),

                 };

var content="<br>"+"MI POSICION =) "+"</br>";

var infowindow = new google.maps.InfoWindow({
    content: content
  })

 var marker = new google.maps.Marker({
            position:{lat:  4.555911, lng:-75.659844} ,
            icon: image,
            map: map
          });

 marker.addListener('click', function() {
    infowindow.open(map, marker);
  });



//enviamos el dia que queremos filtrar
var parametros = {
    "fechaDia" :'0' 
  };



$.ajax({
    url: "php/consultaEstablecimientos.php",
    type: 'POST',
    data: parametros,
    dataType:"json",
    async:false,
    cache:false,
    success: function(establecimientos) {
      console.log("bien recargo Pagina");
  

     if(establecimientos.length!=0)
     {
      
      for(var i=0;i<establecimientos.length;i++)
      {  
      var coordenadas=establecimientos[i].UbicacionGps.split(",");


        var myLatlng = new google.maps.LatLng(coordenadas[0],coordenadas[1]);




        var informacion=establecimientos[i].nombre;

          
        var marker=new google.maps.Marker({
         position: myLatlng,
         map: map,
         title:informacion,
         visible:true,
         clickable:true
       });
     


        var info= new google.maps.InfoWindow();


//c= "Nombre: "+arreglovalores.nombreUsuarioFacebook  +"<br>"+"Telefono:"+arreglovalores.telefonoUsuario+"</br>"+"Ubicacion:"+x[0]+"<br>"+"Ciudad: "+ciudad+"<br>"+"Emergencia: "+arreglovalores.emergencia+"</br>"+"Fecha: "+arreglovalores.fecha+"<br>"+"Hora: "+arreglovalores.hora+"</br>";
       
        var content= '<div style="border-radius:16px;opacity:0.8;">'+"Nombre: "+establecimientos[i].nombre+
        "<br>"+"Telefono: "+establecimientos[i].telefono+
        "</br>"+"Descripcion: "+establecimientos[i].descripcion+"</br>"+
        "Hora: "+establecimientos[i].hora+"</br>"+
        "Ubicacion: "+establecimientos[i].UbicacionGps+"<br>"+
        "Direccion: "+establecimientos[i].direccion+"<br>";
        
//evento para colocar los info en los respectivos marker
google.maps.event.addListener(marker,'click', (function(marker,content,info){ 
  return function() {
    info.setContent(content);
    info.open(map,marker);
  };
})(marker,content,info)); 

}//for





     }//if
    
     
   }//sucess

});



  



}//init map




  </script>

</head>





<div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobsile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Administrador de Establecimientos</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
        
               
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Luce <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
                    <li>
                        <a href="regitrarEstablecimientos.php"><i class="fa fa-fw fa-bar-chart-o"></i> Registros Establecimientos</a>
                    </li>
                    <li>
                        <a href="informacionEstablecimiento.php"><i class="fa fa-fw fa-table"></i>Informacion Establecimientos</a>
                    </li>
                   
                    
                
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Inicio <small>Mapa</small>
                        </h1>
                        
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                <body onload="initMap();">
                <div id="map"></div>  
           
               </body>

                </div>
                <!-- /.row -->

             

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
</html>