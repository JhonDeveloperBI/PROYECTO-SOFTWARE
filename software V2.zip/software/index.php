<?php
session_start();
?>
<html>
	<head>
		<title>.: RLPHP :.</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	</head>
	<body>
	<?php include "php/navbar.php"; ?>
	<div class="container">
	<div class="row">
	<div class="col-md-12">
			<h2>ADMINISTRADOR DE ESTABLECIEMIENTOS</h2>
			<p class="lead">
			<</b>SISTEMA DE UBICACION DE ESTABLECIMIENTOS</p>
			
		
	</div>
	</div>
	</div>
	</body>
</html>