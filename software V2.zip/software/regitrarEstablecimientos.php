<?php
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
print "<script>alert(\"Acceso invalido!\");window.location='login.php';</script>";
}

?>


<!DOCTYPE html>
<html>
<?php include "php/navbar.php"; ?>
<head>
 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>
 <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

<!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
   <!--
    <script src="js/plugins/morris/raphael.min.js"></script>
    <script src="js/plugins/morris/morris.min.js"></script>
    <script src="js/plugins/morris/morris-data.js"></script>
   -->

<script type="text/javascript">
	
function enviar()
{
var a=document.getElementById('nombre');
var b=document.getElementById('direccion');
var c=document.getElementById('telefono');
var d=document.getElementById('descripcion');
var e=document.getElementById('hora');
var f=document.getElementById('ubicacion');

if(a!=null&&b!=null&&c!=null&&d!=null&&e!=null&&f!=null)
	return true;
else
	{
		alert("Llene todos los campos por favor");
		return false;}

}


</script>



	<style type="text/css">
	
	@import url(https://fonts.googleapis.com/css?family=Fauna+One|Muli);
	/*//to load google fonts in our page.*/
	#form{
		background-color:white;
		color:#123456;
		box-shadow:0px 1px 1px 1px gray;
		font-Weight:400;
		width:474px;
		margin:-94px 250px 0 265px;
		float:left;
		height:685px;
	}
	#form div{
		padding:10px 0 0 30px;
	}
	h3{
		margin-top:0px;
		color:white;
		background-color:#337ab7;;
		text-align:center;
		width:100%;
		height:60px;
		padding-top:30px;
	}
	#mainform{
		width:960px;
		margin:20px auto;
		padding-top:20px;
		font-family: 'Fauna One', serif;
	}
	#mainform h2{
		width:100%; float:left;
	}
	input{
		width:90%;
		height:30px;
		margin-top:10px;
		border-radius:3px;
		padding:2px;
		box-shadow:0px 1px 1px 0px darkgray;
	}

	.innerdiv{
		width:65%; float:left;
	}
	input[type=button]{
		background-color:#4f4972;
		border:1px solid white;
		font-family: 'Fauna One', serif;
		font-Weight:bold;
		font-size:18px;
		color:white;
	}
	#clear{clear:both;
	}
	/*CSS for right side advertizement*/
	#formget{
		float:right;
		width:30%;
		margin-top:30px;
	}

 

	</style>


	<title>Registrar Establecimiento</title>
	<script src="jquery-1.6.1.min.js"></script>
</head>



<div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobsile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">Administrador de Establecimientos</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
        
               
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Luce <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
                    <li>
                        <a href="regitrarEstablecimientos.php" style="margin-right:20px"><i class="fa fa-fw fa-bar-chart-o"></i> Registros Establecimientos</a>
                    </li>
                    <li>
                        <a href="informacionEstablecimiento.php"><i class="fa fa-fw fa-table"></i>Informacion Establecimientos</a>
                    </li>
                   
                    
                
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            

                        </h1>
                        
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                <!--<body onload="initMap();">-->
			
			<body>



	<div id="mainform">
		<div class="innerdiv">
			
			<form id="form" name="form" action="php/registrarEstablecimientobase.php" onsubmit="return enviar();" method="post">
			<h3>Ingresa Informacion!</h3>
				<div>
					<label>Nombre :</label>
					<input id="nombre" name="nombre" type="text" required>
					<label>Direccion :</label>
					<input id="direccion" name="direccion" type="text" required>
					<label>Telefono :</label>
					<input id="telefono"  name="telefono" type="text" required>
					<label>Hora atencion :</label>
					<input id="hora" name="hora" type="text" required>
					<label>Ubicacion Gps:</label>
					<input id="ubicacion" name="ubicacion" type="text" required>
					<label>Descripcion:</label>
					<input id="descripcion"  name="descripcion"style="
					width:97%;
					height:85px;
					margin-top:10px;
					border-radius:3px;
					padding:2px;
					box-shadow:0px 1px 1px 0px darkgray; " 
					type="text" required>
					 <button type="submit" class="btn btn-primary" style="padding:15px; margin:10px 115px; background-color: #337ab7;
    border-color: #2e6da4;color: #fff; border-radius: 4px;">Registrar Establecimiento</button>
				
				</div>
			</form>
			<div id="clear"></div>
		</div>
		<div id="clear"></div>
	</div>



</body>

            
                </div>
                <!-- /.row -->

             

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->


</html>