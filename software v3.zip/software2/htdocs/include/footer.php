
	<!-- footer -->
	<div class="copyright">
		<div class="container">
			<div class="agileinfo">
				<p>Proyecto final Ing. Software II</p>
				<p>© 2016 Tasty . All Rights Reserved . Design by <a href="#">W3layouts</a></p>
			</div>
		</div>
	</div>
	<!-- //foter -->
</body>	
</html>