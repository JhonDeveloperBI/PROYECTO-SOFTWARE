<?php
require_once("BaseDatos.php");
/************************
$host = "mysql15.000webhost.com";
$port = 3306;
$bd = "a4940393_biblio";
$user = "a4940393_createS";
$pw = "b123654";
************************/
define("HOST", "sql212.byethost5.com");
define("PORT", 3306);
define("USER", "b5_19129423");
define("PASSWORD", "s123654");
define("BD", "b5_19129423_Fasty");
$db = new BaseDatos(HOST,PORT,USER,PASSWORD,BD);
//$db->ejecutarConsulta("set names'utf8'");
?>